"""Render the 18-second master. Requires numpy, opencv-python-headless, imageio-ffmpeg."""
from pathlib import Path
import math, subprocess, wave
import numpy as np
import cv2 as cv
import imageio_ffmpeg

P=Path(__file__).resolve().parent
F=imageio_ffmpeg.get_ffmpeg_exe()
FPS=30
D=18
W,H=1920,1080
S=1.5
AA=cv.LINE_AA
BLACK=(0,0,0)
BLUE=(228,189,89)
DIM=(112,77,37)
PALE=(240,239,192)
AMBER=(64,154,251)
def g(x):
    x=np.clip(x,0,1)
    return x*x*(3-2*x)
def coord(x,y):return (round(x*S),round(y*S))
def line(m,a,b,c,w=1):cv.line(m,coord(*a),coord(*b),c,w,AA)
def txt(m,x,y,s,sz,col=BLUE,th=1):
    cv.putText(m,s,coord(x,y),cv.FONT_HERSHEY_SIMPLEX,sz*S,col,th,AA)
def arc(m,cx,cy,r,a,b,c,w=1,vertical=1):
    cv.ellipse(m,coord(cx,cy),(round(S*r),round(S*r*vertical)),0,a,b,c,w,AA)
def tri(m,cx,cy,r,col,w=1):
    pts=np.array([coord(cx+r*math.cos(a),cy+r*math.sin(a)) for a in [-5*math.pi/6,-math.pi/6,math.pi/2]],np.int32)
    cv.polylines(m,[pts],True,col,w,AA)
def fresh():return np.zeros((H,W,3),np.uint8)

# Plate contours. A half-model is mirrored, engraved and projected in perspective.
plates=[
 [(0,-208),(25,-205),(50,-191),(60,-167),(55,-135),(41,-118),(32,-145),(0,-153)],
 [(0,-147),(31,-139),(42,-117),(58,-131),(54,-105),(40,-88),(32,-65),(16,-53),(0,-52)],
 [(54,-150),(62,-160),(69,-142),(66,-112),(56,-98),(49,-81),(40,-77),(52,-107)],
 [(0,-66),(17,-64),(31,-72),(24,-54),(11,-47),(0,-47)],
 [(6,-44),(29,-50),(48,-67),(74,-41),(48,-19),(24,-12),(6,-18)],
 [(9,-9),(49,-23),(79,-40),(114,-47),(139,-32),(122,-7),(82,20),(32,36),(15,16)],
 [(123,-52),(164,-54),(190,-42),(215,-13),(218,12),(183,4),(156,-8),(134,-29)],
 [(151,-8),(178,8),(197,16),(181,58),(158,80),(132,65),(122,43)],
 [(194,19),(216,25),(219,57),(207,99),(187,121),(166,104),(180,75)],
 [(41,41),(84,27),(121,5),(128,31),(115,58),(81,77),(42,83),(22,65)],
 [(19,76),(48,87),(82,84),(108,69),(98,101),(63,118),(29,111),(12,97)],
 [(13,111),(53,124),(89,115),(82,141),(49,152),(14,144),(3,130)],
 [(6,147),(46,160),(79,149),(80,169),(62,185),(21,181),(5,165)],
 [(109,70),(130,58),(149,82),(142,108),(119,137),(95,144),(101,115)]
]
def armor(t):
    m=fresh(); z=1+.06*g(t/3)+3.7*g((t-4.1)/1.3)
    # Camera travels from visor to sternum as the arc core takes the frame.
    cy=395-56*g((t-4.1)/1.3)*z
    yaw=.22*(1-g(t/3.7))-.025
    def proj(p):
        x,y=p
        depth=32*math.cos(min(abs(x)/215,1)*1.5)
        return (640+z*(x*math.cos(yaw)+depth*math.sin(yaw)),cy+z*y)
    for side in (-1,1):
        for j,poly in enumerate(plates):
            pts=np.array([proj((side*x,y)) for x,y in poly])
            center=pts.mean(axis=0)
            def vertices(k):return np.int32((center+(pts-center)*k)*S)
            cv.fillPoly(m,[vertices(1)],(24+j%3*3,15+j%3*3,8),AA)
            for k in np.arange(.13,1,.052):
                cv.polylines(m,[vertices(k)],True,(49+int(22*k),32+int(20*k),15+int(12*k)),1,AA)
            cv.polylines(m,[vertices(1)],True,BLUE,2,AA)
            cv.polylines(m,[vertices(.91)],True,DIM,1,AA)
            for a,b in zip(pts,np.roll(pts,1,axis=0)):
                v=a*.87+b*.13
                cv.circle(m,coord(*v),2,PALE,-1,AA)
        eyes=np.int32([coord(*proj((side*x,y))) for x,y in [(5,-113),(40,-119),(35,-109),(14,-107)]])
        cv.fillPoly(m,[eyes],PALE,AA)
    cx,corey=proj((0,51))
    for k in range(5):tri(m,cx,corey,(38-k*4)*z,PALE if k in (1,4) else DIM,max(1,round(z*1.6)))
    scan=int((t*.68%1)*H)
    # Scan exposure follows the contours rather than washing out black space.
    gain=(.61+.64*np.exp(-((np.arange(H)-scan)/48)**2))*g(t/.65)
    if t<1.6:gain*=.06+.94*g((t/1.6*H-np.arange(H)+110)/110)
    return (m*gain[:,None,None]).clip(0,255).astype('uint8')

raw=cv.imdecode(np.fromfile(P/'reactor.png',np.uint8),1)
def reactor(t):
    lt=t-5.4; q=g(lt/1.25)
    scale=.58+.16*q+.035*math.sin(max(0,lt)*.75)+1.55*g((lt-3.6)/1.4)
    h,w=raw.shape[:2]; k=H/h*scale
    aff=cv.getRotationMatrix2D((w/2,h/2),-4+4*q,k)
    aff[:,2]+=[(W-w)/2,(H-h)/2]
    m=cv.warpAffine(raw,aff,(W,H))
    for i in range(3):
        radius=(236+i*8)*scale/.65
        for j in range(4):
            a=j*90+lt*(12 if i%2 else -17)
            arc(m,640,360,radius,a,a+52,BLUE if i==1 else DIM,2)
    return m

rng=np.random.default_rng(7017)
# Unevenly spaced luminous latitudes and a fine independent dust population.
u=np.repeat(np.linspace(.018,math.pi-.018,142),265)
v=np.tile(np.linspace(0,math.tau,265,endpoint=False),142)
u+=rng.normal(0,.0014,len(u));v+=rng.normal(0,.002,len(u))
star=rng.random((1250,3))
def neural(t):
    lt=t-10.4
    angle=v+lt*.32
    rr=1+.17*np.sin(3*u+3*v-lt*1.9)+.085*np.sin(6*u-2*v+lt*1.45)
    a=rr*np.sin(u)*np.cos(angle);b=rr*np.cos(u)*.87;c=rr*np.sin(u)*np.sin(angle)
    y=b*.94+c*.34; depth=c*.94-b*.34
    k=(173+50*g(lt/2.3)-30*g((lt-4)/2))*(1+.15*depth)
    cx=640-101*g((lt-4.3)/1.35)
    px=((cx+k*a)*S).astype(int);py=((349+k*y)*S).astype(int)
    m=fresh()
    xx=((star[:,0]*1280+lt*(star[:,2]*8+1))%1280*S).astype(int)
    yy=(star[:,1]*H).astype(int)
    m[yy,xx]=(80,47,23)
    strength=(.1+.65*((depth+1.5)/3).clip(0,1)**2+.64*np.maximum(0,np.cos(5*u+2*v-lt*2))**12)
    colors=np.column_stack([255*strength,218*strength**1.13,124*strength**1.7]).clip(0,255).astype('uint8')
    # Continuous filaments reveal the curvature between individual sample points.
    strands=np.stack((px,py),axis=1).reshape(142,265,2).astype('int32')
    for k0 in range(3,140,6):
        st=strands[k0]
        for seg in range(0,252,14):
            lumin=float(strength[265*k0+seg])
            tint=tuple(int(min(255,q*lumin)) for q in (154,112,49))
            cv.polylines(m,[st[seg:seg+15]],False,tint,1,AA)
    for k0 in range(2,265,23):
        cv.polylines(m,[strands[12:131,k0].copy()],False,(59,38,15),1,AA)
    m[py,px]=colors
    bright=strength>.64
    m[py[bright]+1,px[bright]]=colors[bright]
    m[py[bright],px[bright]+1]=colors[bright]
    for j in range(3):
        r=246+j*7
        for a0 in range(0,360,90):
            ang=a0+lt*(8+j*3)
            arc(m,cx,586,r,ang,ang+56,DIM if j!=1 else BLUE,1,.09)
    return m

def readout(m,x,y,w,name,value,phase,t):
    txt(m,x,y,name,.33,BLUE);line(m,(x,y+10),(x+w,y+10),DIM)
    txt(m,x,y+44,value,.83,PALE,2)
    pts=[]
    for j in range(105):
        z=math.sin(j*.18+t*2+phase)*5+math.sin(j*.51-t*3)*3+math.sin(j*.95+t)*1.4
        z+=12*math.exp(-((j-(t*21+phase*10)%105)/4)**2)
        pts.append(coord(x+j*w/104,y+75-z))
    cv.polylines(m,[np.int32(pts)],False,BLUE,1,AA)
    for j in range(8):line(m,(x+j*w/8,y+87),(x+j*w/8,y+90),DIM)
def interface(t):
    m=fresh();scene=0 if t<5.4 else 1 if t<10.4 else 2
    if t<.18:return m
    txt(m,41,44,'J A R V I S    /    M A R K   V I I',.45,PALE)
    txt(m,1036,44,'S T A R K   L A B S',.43,BLUE)
    line(m,(41,60),(1238,60),DIM)
    for i in range(3):line(m,(42+i*37,61),(71+i*37,61),AMBER if scene==i else DIM,3)
    for x in [42,1238]:
        for y in [81,637]:
            line(m,(x-4,y),(x+4,y),DIM);line(m,(x,y-4),(x,y+4),DIM)
    txt(m,42,677,f'BOOT  /  0{scene+1}',.41,BLUE)
    txt(m,1010,677,'T+ %02d:%02d.%02d'%(0,int(t),int(t*100)%100),.47,PALE)
    if t<.7:return m
    late=g((t-14.6)/1.4)
    readout(m,54,196,156,['SUIT TELEMETRY','COIL TELEMETRY','NEURAL TELEMETRY'][scene],
        ['%03d / 128'%min(128,int(t*32)),'%04.1f TW'%(2.4+1.1*g((t-5.4)/3)),'%04.1f Hz'%(48+.12*math.sin(t*3))][scene],0,t)
    txt(m,54,388,['CONTOUR MAP','FLUX DENSITY','SIGNAL ARRAY'][scene],.34,BLUE)
    for i in range(23):
        a=(math.sin(i*.28+t*1.9)+1)*.5
        hh=5+int(36*a*(.4+.6*abs(math.cos(i*.2-t))))
        line(m,(55+i*6,450),(55+i*6,450-hh),AMBER if i>19 else BLUE,3)
    if late<.02:
        readout(m,1060,196,165,['OPTICAL LINK','FIELD RESONANCE','PHASE CORRELATION'][scene],
             ['LOCK','%04.1f kHz'%(17+.5*math.sin(t)),'%.3f'%(0.985+.007*math.sin(t))][scene],2,t)
        txt(m,1060,388,'SYSTEM BUS',.34,BLUE)
        for j,name in enumerate(['SYNC','I/O','LINK']):
            txt(m,1060,416+j*21,name,.32,DIM)
            txt(m,1176,416+j*21,'PASS' if t>.95+j*.55 else '....',.32,PALE)
    else:
        title=np.zeros_like(m)
        txt(title,826,313,'J.A.R.V.I.S.    /    PERSONAL INTERFACE',.37,BLUE)
        txt(title,822,394,'COODEX',2.58,PALE,4)
        line(title,(828,419),(1186,419),DIM)
        cv.circle(title,coord(833,452),4,AMBER,-1,AA)
        txt(title,849,458,'SYSTEM ONLINE',.57,PALE)
        m=cv.addWeighted(m,1,title,float(late),0)
    caption=['01     ARMOR MAPPING','02     ARC IGNITION','03     NEURAL SYNTHESIS'][scene]
    if late<.5:txt(m,520,630,caption,.42,PALE)
    return m
def sound():
    sr=48000; x=np.arange(sr*D)/sr; bed=np.zeros((len(x),2)); fx=bed.copy()
    for i,hz in enumerate([49,73.42,98,146.83,196]):
        env=(.065/(1+i*.35))*(.73+.27*np.sin(x*.75+i))
        for ch in range(2):bed[:,ch]+=env*np.sin(math.tau*x*(hz+ch*.13)+.19*np.sin(x*.8))
    bed*= (g(x/1.8)*g((D-x)/1.8))[:,None]
    def chirp(at,d,a,b,amp,pan=.5):
        mask=(x>=at)&(x<at+d);u=x[mask]-at
        env=g(u/min(.024,d*.15))*g((d-u)/(d*.52))
        v=amp*env*np.sin(math.tau*(a*u+.5*(b-a)*u*u/d))
        fx[mask]+=v[:,None]*np.array([1-pan*.7,.3+pan*.7])
    for i in range(18):
        chirp(.5+i*.253,.052,640+i*17,1020+i*11,.065,.1+.8*(i%2))
    for at in (4.1,9.05):
        chirp(at,1.28,64,630,.13);chirp(at+1.28,.65,140,37,.24)
    for i,at in enumerate([5.41,6.6,7.8,10.45,14.8,15.08,15.36]):
        hz=[196,294,392,147,392,494,587.3][i];chirp(at,.82,hz,hz*1.001,.14)
    voice=bed*0
    for at,name in [(1.05,'voice1.wav'),(11.15,'voice2.wav')]:
        p=P/name
        if not p.exists():continue
        data=subprocess.check_output([F,'-v','error','-i',str(p),'-af','highpass=f=135,lowpass=f=6000','-f','f32le','-ar','48000','-ac','1','-'])
        s=np.frombuffer(data,'<f4');s=s*(.49/max(.01,np.max(abs(s))))
        off=int(at*sr);voice[off:off+len(s)]+=s[:,None]
        voice[off+1350:off+1350+len(s)]+=s[:,None]*.08
    for name,arr in [('03_atmosphere',bed),('04_interface_sfx',fx),('05_voice',voice),('06_mix',bed+fx+voice)]:
        with wave.open(str(P/(name+'.wav')),'wb') as f:
            f.setparams((2,2,sr,0,'NONE',''));f.writeframes((np.clip(arr,-1,1)*32767).astype('<i2').tobytes())
def writer(path,args):
    return subprocess.Popen([F,'-y','-v','error','-f','rawvideo','-pix_fmt','bgr24','-s',f'{W}x{H}','-r',str(FPS),'-i','-','-c:v','libx264','-threads','4','-preset','veryfast',*args,str(path)],stdin=subprocess.PIPE)
def build():
    cv.setNumThreads(2)
    sound()
    base=P/'01_clean_picture.mp4'; ui=P/'02_HUD_screen.mp4'
    writers=[writer(base,['-crf','15','-pix_fmt','yuv420p']),writer(ui,['-crf','13','-pix_fmt','yuv420p'])]
    for n in range(D*FPS):
        t=n/FPS
        m=armor(t) if t<5.4 else reactor(t) if t<10.4 else neural(t)
        small=cv.resize(m,(480,270),interpolation=cv.INTER_AREA)
        glow=cv.resize(cv.GaussianBlur(small,(0,0),3.7),(W,H))
        flash=max(max(0,1-abs(t-cut)/.19)**3 for cut in (5.4,10.4))
        m=cv.addWeighted(m,1,glow,.47,2)
        if flash>.001:m=cv.addWeighted(m,1-.57*flash,np.full_like(m,(220,197,139)),flash,0)
        hud=interface(t)
        writers[0].stdin.write(m.tobytes());writers[1].stdin.write(hud.tobytes())
    for p in writers:p.stdin.close()
    for p in writers:
        if p.wait():raise RuntimeError('render failed')
    subprocess.run([F,'-y','-v','error','-i',str(base),'-i',str(ui),'-i',str(P/'06_mix.wav'),'-filter_complex','[0:v]format=gbrp[a];[1:v]format=gbrp[b];[a][b]blend=all_mode=screen,format=yuv420p[out]','-map','[out]','-map','2:a','-c:v','libx264','-crf','16','-preset','fast','-pix_fmt','yuv420p','-c:a','aac','-b:a','256k','-movflags','+faststart',str(P.parent/'JARVIS_觉醒.mp4')],check=True)
if __name__=='__main__':build()
